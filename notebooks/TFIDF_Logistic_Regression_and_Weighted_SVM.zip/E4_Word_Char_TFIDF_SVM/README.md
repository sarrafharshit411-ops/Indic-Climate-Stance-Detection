# E4 Word Char TFIDF SVM

Open the `.ipynb` notebook in Google Colab and choose **Runtime → Run all**.

- The cleaned Indic Climate dataset is embedded inside the notebook.
- No dataset upload or path selection is required.
- The notebook trains separate Hindi and Bengali models.
- It evaluates validation and test splits and saves metrics, classification reports,
  confusion matrices, predictions, and trained model files.
- The final cell automatically downloads a ZIP containing the outputs and a notebook copy.

Dataset label mapping: `0 = Against`, `1 = Favour`, `2 = None`.
