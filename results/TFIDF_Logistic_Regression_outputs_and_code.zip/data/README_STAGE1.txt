STAGE 1 CLEANED DATASET
=======================

This folder contains six CSV files with the same rows and labels as the source ZIP.

Cleaning performed:
- Collapsed repeated whitespace and trimmed leading/trailing whitespace in original_text and text.
- Preserved wording, punctuation, URLs, hashtags, mentions, labels, IDs, language, and split assignments.
- No rows were intentionally deleted.
- No labels were changed.
- No translation was manually corrected in this stage.

Files:
- hindi_train.csv, hindi_val.csv, hindi_test.csv
- bengali_train.csv, bengali_val.csv, bengali_test.csv
- stage1_file_audit.csv
- cross_language_integrity_check.csv
- label_distribution.csv

Important:
This is structural/text-format cleaning only. It does NOT certify translation quality.
Review flagged translations separately before deciding whether to correct, exclude, or retain them.
Label mapping: 0 = Against, 1 = Favour, 2 = None.
