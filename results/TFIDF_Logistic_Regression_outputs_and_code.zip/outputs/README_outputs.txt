
TFIDF_Logistic_Regression
=================

Dataset: Indic Climate Stage 1 cleaned dataset (Hindi + Bengali).
Label mapping: 0=Against, 1=Favour, 2=None.

This run trains one model per language using the provided train split.
The validation split and test split are evaluated separately.
TF-IDF vectorizers are fitted on training text only.

Outputs include:
- metrics summary (accuracy, macro-F1, weighted-F1)
- classification reports for validation and test
- confusion matrices for validation and test
- predictions for validation and test
- serialized trained models (.joblib)

Important: This is an experimental baseline. Review translation quality and
dataset documentation before making claims about model generalization.
